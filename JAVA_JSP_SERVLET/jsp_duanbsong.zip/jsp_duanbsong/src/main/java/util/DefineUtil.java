package util;

public class DefineUtil {
	public static final int NUMBER_PER_PAGE = 4;
}
