package controller.publicc;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Categories;
import model.bean.Songs;
import model.dao.CatergoriesDAO;
import model.dao.SongsDAO;

import java.io.IOException;

public class DetailPublicController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DetailPublicController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int dtId = Integer.parseInt(request.getParameter("dtid"));
		CatergoriesDAO catDao = new CatergoriesDAO();
		Categories objCat = catDao.getCatByID(dtId);
		SongsDAO songDAO = new SongsDAO();
	    Songs song = songDAO.getSongByID(dtId);
	    
//	    SongsDAO otherSong = new SongsDAO();
//      	Songs objS = otherSong.getRanDomOtherSong(dtId);
//      	request.setAttribute("objS", objS);
		request.setAttribute("song", song);
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/public/detail.jsp");
		rd.forward(request, response);
	}

}
