package controller.publicc;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Contacts;
import model.dao.ContactsDAO;

import java.io.IOException;

public class ContactPublicController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ContactPublicController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String website = request.getParameter("website");
		String mess = request.getParameter("message");
		Contacts obj = new Contacts(0, name, email, website, mess);
		ContactsDAO dao = new ContactsDAO();
		int msg = 0;
		if(dao.addContact(obj) > 0) {
			System.out.println("Thêm liên hệ thành công");
			response.sendRedirect(request.getContextPath() + "/publicc/show-contact");
		} else {
			System.out.println("Thêm liên hệ thất bại");
			response.sendRedirect(request.getContextPath() + "/publicc/show-contact");
		}
		
	}

}
