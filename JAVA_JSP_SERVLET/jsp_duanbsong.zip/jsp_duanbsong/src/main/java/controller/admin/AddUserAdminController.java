package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Users;
import model.dao.UsersDAO;

import java.io.IOException;

public class AddUserAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddUserAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String pass = request.getParameter("password");
		String fullname = request.getParameter("fullname");
		UsersDAO dao = new UsersDAO();
		Users user = new Users(0, username, pass, fullname);
		if(dao.addUser(user) > 0) {
			System.out.println("Thêm user thành công");
			response.sendRedirect(request.getContextPath() + "/admin/users");
		}else {
			System.out.println("Thêm user thất bại");
			response.sendRedirect(request.getContextPath() + "/admin/users");
		}
	}

}
