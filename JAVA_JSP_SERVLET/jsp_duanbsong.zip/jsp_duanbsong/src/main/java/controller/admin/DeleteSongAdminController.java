package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.dao.SongsDAO;

import java.io.IOException;

public class DeleteSongAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeleteSongAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int dsid = Integer.parseInt(request.getParameter("dsid"));
		SongsDAO dao = new SongsDAO();
		dao.deleteSong(dsid);
		response.sendRedirect(request.getContextPath() + "/admin/songs");
	}

}
