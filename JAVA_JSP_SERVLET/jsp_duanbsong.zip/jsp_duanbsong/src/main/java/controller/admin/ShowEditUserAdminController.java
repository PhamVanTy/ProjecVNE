package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Users;
import model.dao.UsersDAO;

import java.io.IOException;

public class ShowEditUserAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ShowEditUserAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("eid"));
		UsersDAO dao = new UsersDAO();
		Users user = dao.getUserByID(id);
		request.setAttribute("user", user);
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/editUser.jsp");
		rd.forward(request, response);
	}

}
