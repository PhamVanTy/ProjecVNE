package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Categories;
import model.bean.Songs;
import model.dao.CatergoriesDAO;
import model.dao.SongsDAO;
import util.FileUtil;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
@MultipartConfig
public class EditSongAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditSongAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sname = request.getParameter("name");
		int scategory = Integer.parseInt(request.getParameter("category"));
		int sid = Integer.parseInt(request.getParameter("id"));
		String spicture = FileUtil.upload("picture", request);
		String spreview = request.getParameter("preview");
		String sdetail = request.getParameter("detail");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String date = sdf.format(new Date());
//		System.out.println(spicture);
		Songs song = new Songs(sid, sname, spreview, sdetail, date, spicture, 0, scategory);
		SongsDAO editSongDAO = new SongsDAO();
		if(editSongDAO.editItem(song) > 0) {
			System.out.println("Update bài hát thành công");
			response.sendRedirect(request.getContextPath()+"/admin/songs");
		}else {
			System.out.println("Update không thành công");
			response.sendRedirect(request.getContextPath()+"/admin/songs");
		}	
		
	}

}
