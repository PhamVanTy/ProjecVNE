package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Contacts;
import model.dao.ContactsDAO;

import java.io.IOException;

public class DeleteContactAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeleteContactAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int did = Integer.parseInt(request.getParameter("did"));
		ContactsDAO dao = new ContactsDAO();
		dao.delContact(did);
		response.sendRedirect(request.getContextPath() + "/admin/contacts");
	}

}
