package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Contacts;
import model.dao.ContactsDAO;

import java.io.IOException;

public class ShowEditContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ShowEditContactController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int eid = Integer.parseInt(request.getParameter("eid"));
		ContactsDAO dao = new ContactsDAO();
		Contacts objContact = dao.getContactByID(eid);
		request.setAttribute("objContact", objContact);
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/editContact.jsp");
		rd.forward(request, response);
	}

}
