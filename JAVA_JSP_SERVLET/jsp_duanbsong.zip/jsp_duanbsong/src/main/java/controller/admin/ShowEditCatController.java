package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Categories;
import model.dao.CatergoriesDAO;

import java.io.IOException;

public class ShowEditCatController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ShowEditCatController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int cid = Integer.parseInt(request.getParameter("cid"));
		CatergoriesDAO dao = new CatergoriesDAO();
		Categories objCatEdit = dao.getCatByID(cid);
//		System.out.println(objCatEdit);
		request.setAttribute("objCatEdit", objCatEdit);
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/editCat.jsp");
		rd.forward(request, response);
	}

}
