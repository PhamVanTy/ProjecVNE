package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Categories;
import model.dao.CatergoriesDAO;

import java.io.IOException;

public class EditCatAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditCatAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int idCatEdit = Integer.parseInt(request.getParameter("idCatEdit"));
		String nameCat = request.getParameter("editCatName");
		Categories objCatEdit = new Categories(idCatEdit, nameCat);
		CatergoriesDAO editCatDAO = new CatergoriesDAO();
		if(editCatDAO.editItem(objCatEdit) > 0) {
			System.out.println("Update thành công");
			response.sendRedirect(request.getContextPath()+"/admin/cats");
		}else {
			System.out.println("Update không thành công");
			response.sendRedirect(request.getContextPath()+"/admin/cats");
		}

		
		
	}

}
