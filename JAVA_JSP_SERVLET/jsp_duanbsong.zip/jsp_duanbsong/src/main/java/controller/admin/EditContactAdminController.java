package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Contacts;
import model.dao.ContactsDAO;

import java.io.IOException;

public class EditContactAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditContactAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id_contact"));
		String name = request.getParameter("username");
		String email = request.getParameter("email");
		String website = request.getParameter("website");
		String message = request.getParameter("message");
		ContactsDAO dao = new ContactsDAO();
		Contacts contact = new Contacts(id, name, email, website, message);
		if(dao.editContact(contact) > 0) {
			System.out.println("Sửa thành công");
			response.sendRedirect(request.getContextPath() + "/admin/contacts");
		}else {
			System.out.println("Sủa thất bại");
			response.sendRedirect(request.getContextPath() + "/admin/contacts");
		}
	}

}
