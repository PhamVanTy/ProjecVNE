package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Songs;
import model.dao.SongsDAO;

import java.io.IOException;

public class ShowEditSongController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ShowEditSongController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int sid = Integer.parseInt(request.getParameter("sid"));
		SongsDAO sDao = new SongsDAO();
		Songs objS = sDao.getSongByID(sid);
		request.setAttribute("objs", objS);
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/editSong.jsp");
		rd.forward(request, response);
	}

}
