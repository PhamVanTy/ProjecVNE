package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Categories;
import model.dao.CatergoriesDAO;

import java.io.IOException;

public class AddCatAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddCatAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("catName");
		CatergoriesDAO newCatDAO = new CatergoriesDAO();
		Categories objNewCat = new Categories(0, name);
		int msg = 0;
		if(newCatDAO.addItem(objNewCat) > 0) {
			msg = 1;
			request.setAttribute("msg", msg);
		}else {
			msg = 2;
			request.setAttribute("msg", msg);
		}
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/addCat.jsp");
		rd.forward(request, response);
	}

}
