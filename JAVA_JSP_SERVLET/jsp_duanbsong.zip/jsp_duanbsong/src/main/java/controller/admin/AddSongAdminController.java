package controller.admin;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Songs;
import model.dao.SongsDAO;
import util.FileUtil;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
@MultipartConfig
public class AddSongAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddSongAdminController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		int id_cat = Integer.parseInt(request.getParameter("category"));
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String date = df.format(new Date());
		String filename = FileUtil.upload("picture", request);
		String preview = request.getParameter("preview");
		String detail = request.getParameter("detail");
		Songs song = new Songs(0, name, preview, detail, date, filename, 0, id_cat);
		SongsDAO songDAO = new SongsDAO();
		int msg = 0;
		if(songDAO.addSong(song) > 0) {
			msg = 1;
			request.setAttribute("msg", msg);
		}else {
			msg = 2;
			request.setAttribute("msg", msg);
		}
		RequestDispatcher rd = request.getRequestDispatcher("/GiaoDien/admin/addSong.jsp");
		rd.forward(request, response);
	}

}
