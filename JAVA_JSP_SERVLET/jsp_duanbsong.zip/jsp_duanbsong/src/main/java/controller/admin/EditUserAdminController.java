package controller.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.bean.Users;
import model.dao.UsersDAO;

import java.io.IOException;

public class EditUserAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditUserAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id_user"));
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String fullname = request.getParameter("fullname");
		UsersDAO dao = new UsersDAO();
		Users user = new Users(id, username, password, fullname);
		if(dao.editUser(user) > 0) {
			System.out.println("Sửa user thành công");
			response.sendRedirect(request.getContextPath() + "/admin/users");
		}else {
			System.out.println("Sửa user thất bại");
			response.sendRedirect(request.getContextPath() + "/admin/users");
		}
	}

}
