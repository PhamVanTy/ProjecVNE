package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

import model.bean.Songs;
import util.DBConnectionUtil;

public class SongsDAO {
	private Connection conn;
	private DBConnectionUtil dbConnectionUtil;
	private Statement st;
	private PreparedStatement pst;
	private ResultSet rs;
	public SongsDAO() {
		dbConnectionUtil = new DBConnectionUtil();
	}
	public ArrayList<Songs> getItems() {
		ArrayList<Songs> listSong = new ArrayList<>();
		conn = dbConnectionUtil.getConnection();
		String sql = "SELECT * FROM songs";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				Songs songs = new Songs(rs.getInt("id"), rs.getString("name"), rs.getString("preview_text"), rs.getString("detail_text"), rs.getString("date_create"), rs.getString("picture"), rs.getInt("counter"), rs.getInt("cat_id"));
				listSong.add(songs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listSong;
	}
	
	public ArrayList<Songs> getItemsByIDCat(int plcid) {
		ArrayList<Songs> listSong = new ArrayList<>();
		conn = dbConnectionUtil.getConnection();
		String sql = "SELECT * FROM songs WHERE cat_id="+plcid;
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				Songs songs = new Songs(rs.getInt("id"), rs.getString("name"), rs.getString("preview_text"), rs.getString("detail_text"), rs.getString("date_create"), rs.getString("picture"), rs.getInt("counter"), rs.getInt("cat_id"));
				listSong.add(songs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listSong;
	}
	
	public ArrayList<Songs> getNewItems() {
		ArrayList<Songs> listSong = new ArrayList<>();
		conn = dbConnectionUtil.getConnection();
		String sql = "SELECT * FROM songs ORDER BY id DESC limit 4";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				Songs songs = new Songs(rs.getInt("id"), rs.getString("name"), rs.getString("preview_text"), rs.getString("detail_text"), rs.getString("date_create"), rs.getString("picture"), rs.getInt("counter"), rs.getInt("cat_id"));
				listSong.add(songs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listSong;
	}
	
	public int addSong(Songs song) {
		int result = 0;
		conn = dbConnectionUtil.getConnection();
		String sql = "INSERT INTO songs (id, name, preview_text, detail_text, date_create, picture, counter, cat_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";		
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, song.getIdSong());
			pst.setString(2, song.getSongName());
			pst.setString(3, song.getPreview_text());
			pst.setString(4, song.getDetail_text());
			pst.setString(5, song.getDate_create());
			pst.setString(6, song.getPicture());
			pst.setInt(7, song.getCounter());
			pst.setInt(8, song.getId_cat());
			result = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public Songs getSongByID(int sid) {
		conn = dbConnectionUtil.getConnection();
		String sql = "SELECT * FROM songs WHERE id=?";
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, sid);
			rs = pst.executeQuery();
			while(rs.next()) {
				return new Songs(rs.getInt("id"), rs.getString("name"), rs.getString("preview_text"), rs.getString("detail_text"), rs.getString("date_create"), rs.getString("picture"), rs.getInt("counter"), rs.getInt("cat_id"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public int editItem(Songs song) {
		int result = 0;
		conn = dbConnectionUtil.getConnection();
		String sql = "UPDATE songs SET name=?,preview_text=?,detail_text=?,date_create=?,picture=?,cat_id=? WHERE id=?";
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, song.getSongName());
			pst.setString(2, song.getPreview_text());
			pst.setString(3, song.getDetail_text());
			pst.setString(4, song.getDate_create());
			pst.setString(5, song.getPicture());			
			pst.setInt(6, song.getId_cat());
			pst.setInt(7, song.getIdSong());
			result = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public void deleteSong(int sid) {
		conn = dbConnectionUtil.getConnection();
		String sql = "DELETE FROM songs WHERE id=?";
		try {
			pst = conn.prepareStatement(sql);
			pst.setInt(1, sid);
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
	
}
