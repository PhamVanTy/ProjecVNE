$(document).ready(function(){
	$("#form-contact").validate({
		rules:{
			username: {
				required: true,
			},
			email:{
				email: true,
			},
		},
		messages:{
			username: {
				required: "--Vui lòng nhập tên--",
			},
			email:{
				email: "--Vui lòng nhập đúng email--",
			},			
		},
	})
});